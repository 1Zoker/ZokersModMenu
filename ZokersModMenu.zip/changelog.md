# Changelog

All notable changes to ZokersModMenu will be documented in this file.

## [1.1.0] - 2024-12-19

### 🆕 Major Features Added
- **Increased Joker Limit**: You can now select up to **20 copies** of the same joker (increased from 10)
- **Mika's Mod Collection Integration**: Full compatibility with Mika's Mod Collection
  - Automatic detection of Mika's Mod Collection
  - Dedicated "Mika's Jokers" tab when mod is available
  - Over 60 Mika's jokers supported
  - Same 20-copy limit applies to Mika's jokers

### 🎨 UI/UX Improvements
- **Enhanced Color Coding**: New joker count visualization system
  - Green: 1-9 copies
  - Gold: 10-19 copies  
  - Red: 20+ copies (maximum)
- **Dynamic Menu**: Mika's Jokers button appears automatically when mod is detected
- **Separate Pagination**: Independent page tracking for vanilla and Mika's jokers
- **Improved Button Colors**: Mika's button uses distinctive pink theme

### 🔧 Technical Enhancements
- **Smart Mod Detection**: Automatic detection of Mika's Mod Collection presence
- **Modular Joker System**: Separate joker lists for vanilla and modded content
- **Enhanced Dependency Management**: Proper dependency declarations in mod header
- **Improved Menu Navigation**: Better handling of different joker menu types

### 📝 Joker Database Expansion
Added complete Mika's Mod Collection joker support including:
- **Prime Time**, **Straight Nate**, **The Fisherman**, **Impatient Joker**
- **Cultist**, **Seal Collector**, **Camper**, **Scratch Card**
- **Delayed Joker**, **The Show-Off**, **The Sniper**, **Blackjack Joker**
- **Batman**, **Bomb**, **Eye Chart**, **Grudgeful Joker**
- **Finishing Blow**, **Aurora Borealis**, **Historical Joker**, **Suit Alley**
- **The Printer**, **Training Wheels**, **Horseshoe**, **Incomplete Joker**
- **Abbey Road**, **Fishing License**, **Gold Bar**, **Rigged Joker**
- **The Commander**, **Blue Moon**, **Dagonet**, **Glue**
- **Harp Seal**, **Football Card**, **Special Edition Joker**, **The Stockpiler**
- **Student Loans**, **Broke Joker**, **Go For Broke**, **Street Fighter**
- **Checklist**, **One Of Us**, **The Investor**, **Mountain Climber**
- **Shackles**, **Buy One Get One**, **Pack A Punch**, **Seal Steal**
- **Tax Collector**, **Glass Cannon**, **Scoring Test**, **Cicero**
- **Dawn**, **Savings**, **Monopolist**, **Nebula**
- **Cheapskate**, **Psychic Joker**, **Cheat**, **Plus One**

### 🖥️ Console & Commands
- **Enhanced Console Help**: More detailed startup messages and instructions
- **Updated Command List**: `cs_list_jokers()` now shows both vanilla and Mika's jokers
- **Better Error Handling**: Improved feedback for joker addition commands
- **Status Display**: `cs_show()` now indicates Mika's Mod status

### 🔄 Function Updates
- **`cs_toggle_joker()`**: Now supports 20-copy limit and smart menu refreshing
- **`cs_add_joker()`**: Enhanced to search both vanilla and Mika's joker pools
- **`cs_list_jokers()`**: Separated listing for vanilla and Mika's jokers
- **Navigation Functions**: Added Mika's-specific pagination controls

### 🐛 Bug Fixes
- Fixed joker count display inconsistencies
- Improved menu state management when switching between joker types
- Better handling of mod detection edge cases
- Fixed pagination issues with different joker pool sizes

### 📚 Documentation
- **Complete README**: Comprehensive installation and usage guide
- **Manifest File**: Proper metadata and dependency declarations
- **Lovely.toml**: Thunderstore compatibility configuration
- **Console Guide**: Detailed instructions for using console commands
- **Compatibility Notes**: Clear information about Mika's Mod integration

### ⚙️ Technical Details
- **Version**: Updated to 1.1.0
- **Dependencies**: Steamodded 1.0.0~ALPHA-0812d or higher
- **Optional Dependencies**: MikasModCollection (auto-detected)
- **Compatibility**: Maintains backward compatibility with existing saves
- **Performance**: Optimized joker detection and menu rendering

---

## [1.0.0] - 2024-12-18

### 🎉 Initial Release
- **Core Features**: Complete mod framework with all basic functionality
- **Deck Builder**: Custom deck creation with enhancements and seals
- **Joker Selection**: Starting joker selection with up to 10 copies
- **Starting Conditions**: Money, hands, discards, rerolls, slots customization
- **Console Commands**: Full console integration with 15+ commands
- **Keybind Support**: Press 'C' to open menu anywhere
- **Deck Management**: Save/load custom deck configurations
- **Legacy Support**: Automatic conversion of old deck formats

### 🎮 Features Included
- Starting money adjustment ($0-$999)
- Starting hands modification (1-20)
- Starting discards control (0-20)
- Free rerolls toggle
- Joker slots customization (0-100)
- Consumable slots adjustment (0-15)
- Enhanced card support (9 enhancement types)
- Seal system (5 seal types)
- Optional custom deck system

### 💻 Console Commands
- `cs_money()`, `cs_hands()`, `cs_discards()`
- `cs_free_rerolls()`, `cs_slots()`, `cs_consumables()`
- `cs_add_joker()`, `cs_list_jokers()`, `cs_show()`
- `cs_name_deck()`, `cs_save_current_deck()`, `cs_load_deck()`
- `cs_enable_custom_deck()`, `cs_disable_custom_deck()`
- `cs_remove_card()`, `cs_open()`

### 🃏 Joker Support
- All 150+ vanilla Balatro jokers
- Up to 10 copies per joker type
- Color-coded selection interface
- Paginated joker browser

---

## Future Plans

### Potential v1.2.0 Features
- [ ] Blind customization system
- [ ] Voucher selection interface  
- [ ] Enhanced deck templates
- [ ] Import/export deck sharing
- [ ] Advanced filtering options
- [ ] More mod integrations

### Community Requests
- [ ] Stake modification support
- [ ] Challenge mode customization
- [ ] Seed manipulation tools
- [ ] Statistics tracking

---

*For support or feature requests, please contact the mod author or visit the project repository.*