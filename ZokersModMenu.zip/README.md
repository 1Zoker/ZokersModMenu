# ZokersModMenu v1.1.0

A comprehensive customization mod for Balatro that allows you to modify starting conditions, build custom decks, select starting jokers, and much more. Compatible with Mika's Mod Collection for expanded joker selection.

## Features

### 🎮 Core Customization
- **Starting Money**: Adjust your starting cash from $0 to $999
- **Starting Hands**: Set hands per round (1-20)
- **Starting Discards**: Configure discards per round (0-20)
- **Free Rerolls**: Toggle unlimited shop rerolls
- **Joker Slots**: Modify joker capacity (0-100)
- **Consumable Slots**: Adjust consumable capacity (0-15)
- **Hand Size**: Adjust Starting HandSize (1-30)

### 🃏 Deck Builder
- **Custom Deck Creation**: Build decks with up to 104 cards
- **Enhanced Cards**: Add enhancements (Bonus, Mult, Wild, Glass, Steel, Stone, Gold, Lucky)
- **Sealed Cards**: Apply seals (Gold, Red, Blue, Purple)
- **Deck Management**: Save and load custom deck configurations
- **Standard Templates**: Quick-create standard 52-card decks

### 🃏 Joker Selection
- **Starting Jokers**: Choose up to 20 copies of any joker
- **Vanilla Jokers**: All base game jokers available
- **Mika's Integration**: Automatic detection and support for Mika's Mod Collection jokers
- **Smart UI**: Color-coded selection (Green: 1-9, Gold: 10-19, Red: 20)

### 🔧 Advanced Features
- **Optional Custom Decks**: Custom decks are disabled by default - enable when ready
- **Legacy Conversion**: Automatically converts old deck formats
- **Console Commands**: Full console integration for precise control
- **Persistent Storage**: Save deck configurations and settings

## Installation

### Requirements
- **Steamodded**: Version 1.0.0-ALPHA-0812d or higher
- **Optional**: Mika's Mod Collection (for expanded joker selection)

### Steps
1. Download the mod files
2. Place `ZokersModMenu.lua` in your Balatro mods folder
3. If using Lovely injector, include the `lovely.toml` file
4. Launch Balatro and enjoy!

## Usage

### Opening the Menu
- **Keybind**: Press `C` anywhere in the game
- **Console**: Type `cs_open()` in the developer console (F7)

### Navigation
- **Money & Stats**: Adjust starting conditions and slots
- **Build Deck**: Create and customize your deck
- **Select Jokers**: Choose starting jokers from vanilla selection
- **Mika's Jokers**: Access Mika's jokers (if mod is installed)

### Console Commands

#### Basic Configuration
```lua
cs_money(10)           -- Set starting money to $10
cs_hands(6)            -- Set starting hands to 6
cs_discards(5)         -- Set starting discards to 5
cs_free_rerolls(true)  -- Enable free rerolls
cs_slots(10)           -- Set joker slots to 10
cs_consumables(5)      -- Set consumable slots to 5
```

#### Joker Management
```lua
cs_add_joker('credit_card')    -- Add Credit Card joker
cs_list_jokers()              -- List all available jokers
cs_show()                     -- Show current settings
```

#### Deck Management
```lua
cs_name_deck('My Deck')       -- Name current deck
cs_save_current_deck()        -- Save current deck
cs_load_deck('My Deck')       -- Load saved deck
cs_enable_custom_deck()       -- Enable custom deck for games
cs_disable_custom_deck()      -- Use default deck
cs_remove_card('AS')          -- Remove Ace of Spades
```

#### Utility
```lua
cs_open()     -- Open the mod menu
cs_show()     -- Display all current settings
```

**Common Issues:**
- If console doesn't open, ensure developer mode is enabled
- Commands are case-sensitive
- Use exact formatting as shown in examples

## Compatibility

### Mika's Mod Collection Integration
When Mika's Mod Collection is detected, ZokersModMenu automatically:
- Adds a "Mika's Jokers" button to the main menu
- Includes all Mika's jokers in the selection pool
- Maintains the same 20-copy limit for Mika's jokers
- Provides seamless integration with existing functionality

### Supported Mika's Jokers
Over 60 unique jokers including:
- Prime Time, Straight Nate, The Fisherman
- Cultist, Seal Collector, Batman
- Dagonet, Cicero, Plus One
- And many more!

## Tips & Tricks

### Efficient Deck Building
1. Start with a standard 52-card deck template
2. Add enhancements strategically (Glass for high risk/reward)
3. Use seals to complement your strategy
4. Save different deck configurations for various playstyles

### Joker Selection Strategy
1. Consider synergies between multiple copies
2. Use the color coding to track your selections
3. Mix vanilla and Mika's jokers for variety
4. Remember you can have up to 20 of the same joker!

### Custom Deck Usage
1. Build your deck in the deck builder
2. Test it with `cs_enable_custom_deck()`
3. Start a new run to use your custom deck
4. Disable with `cs_disable_custom_deck()` to return to normal

## Version History

### v1.1.0 (Latest)
- **MAJOR**: Increased joker limit from 10 to 20 copies
- **NEW**: Mika's Mod Collection integration with automatic detection
- **NEW**: Separate Mika's Jokers menu when mod is available
- **IMPROVED**: Color coding for joker counts (Green/Gold/Red system)
- **IMPROVED**: Enhanced console help and startup messages
- **IMPROVED**: Better mod compatibility and detection

### v1.0.0
- Initial release with core functionality
- Basic deck building and joker selection
- Console command system
- Free rerolls and stat modification

## Support

If you encounter issues:
1. Check the console for error messages (F7)
2. Verify Steamodded is properly installed
3. Ensure mod files are in the correct directory
4. Try disabling other mods to test compatibility

## Credits

- **Author**: Zoker
- **Special Thanks**: Mika (Mikadoe) for the amazing Mika's Mod Collection
- **Community**: Balatro modding community for testing and feedback

---

*Customize your Balatro experience like never before! 🎲*