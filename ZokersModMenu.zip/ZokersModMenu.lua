--- STEAMODDED HEADER
--- MOD_NAME: ZokersModMenu
--- MOD_ID: ZokersModMenu
--- MOD_AUTHOR: [Zoker]
--- MOD_DESCRIPTION: Customize starting deck, jokers, money, hands, discards, rerolls, and slots. Compatible with Mika's Mod Collection.
--- BADGE_COLOUR: 708b91
--- PREFIX: cs
--- PRIORITY: 0
--- VERSION: 1.1.0
--- DEPENDENCIES: [Steamodded>=1.0.0~ALPHA-0812d]

----------------------------------------------
------------MOD CODE -------------------------

-- Get the mod instance
local mod = SMODS.current_mod

-- Initialize config with default values
mod.config = mod.config or {}

-- Ensure all values exist with defaults
mod.config.starting_money = mod.config.starting_money or 4
mod.config.starting_hands = mod.config.starting_hands or 4
mod.config.starting_discards = mod.config.starting_discards or 3
mod.config.hand_size = mod.config.hand_size or 8
mod.config.free_rerolls = mod.config.free_rerolls or false
mod.config.joker_slots = mod.config.joker_slots or 5
mod.config.consumable_slots = mod.config.consumable_slots or 2
mod.config.custom_deck = mod.config.custom_deck or {}
mod.config.starting_jokers = mod.config.starting_jokers or {}
mod.config.current_deck_name = mod.config.current_deck_name or "Custom Deck"

-- Enhanced card structure with seals and enhancements - DEFINED FIRST
local function create_card_data(rank, suit, enhancement, seal)
    return {
        rank = rank,
        suit = suit,
        enhancement = enhancement or 'base',
        seal = seal or 'none'
    }
end

-- Available vanilla jokers list
local available_jokers = {
    'j_joker', 'j_greedy_joker', 'j_lusty_joker', 'j_wrathful_joker', 'j_gluttonous_joker',
    'j_jolly', 'j_zany', 'j_mad', 'j_crazy', 'j_droll', 'j_sly', 'j_wily', 'j_clever',
    'j_devious', 'j_crafty', 'j_half', 'j_stencil', 'j_four_fingers', 'j_mime',
    'j_credit_card', 'j_ceremonial', 'j_banner', 'j_mystic_summit', 'j_marble',
    'j_loyalty_card', 'j_8_ball', 'j_misprint', 'j_dusk', 'j_raised_fist',
    'j_chaos', 'j_fibonacci', 'j_steel_joker', 'j_scary_face', 'j_abstract',
    'j_delayed_grat', 'j_hack', 'j_pareidolia', 'j_gros_michel', 'j_even_steven',
    'j_odd_todd', 'j_scholar', 'j_business', 'j_supernova', 'j_ride_the_bus',
    'j_space', 'j_egg', 'j_burglar', 'j_blackboard', 'j_runner', 'j_ice_cream',
    'j_dna', 'j_splash', 'j_blue_joker', 'j_sixth_sense', 'j_constellation',
    'j_hiker', 'j_faceless', 'j_green_joker', 'j_superposition', 'j_todo_list',
    'j_cavendish', 'j_card_sharp', 'j_red_card', 'j_madness', 'j_square',
    'j_seance', 'j_riff_raff', 'j_vampire', 'j_shortcut', 'j_hologram',
    'j_vagabond', 'j_baron', 'j_cloud_9', 'j_rocket', 'j_obelisk',
    'j_midas_mask', 'j_luchador', 'j_photograph', 'j_gift', 'j_turtle_bean',
    'j_erosion', 'j_reserved_parking', 'j_mail', 'j_to_the_moon', 'j_hallucination',
    'j_fortune_teller', 'j_juggler', 'j_drunkard', 'j_stone', 'j_golden',
    'j_lucky_cat', 'j_baseball', 'j_bull', 'j_diet_cola', 'j_trading',
    'j_flash', 'j_popcorn', 'j_trousers', 'j_ancient', 'j_ramen',
    'j_walkie_talkie', 'j_selzer', 'j_castle', 'j_smiley', 'j_campfire',
    'j_golden_ticket', 'j_mr_bones', 'j_acrobat', 'j_sock_and_buskin',
    'j_swashbuckler', 'j_troubadour', 'j_certificate', 'j_smeared',
    'j_throwback', 'j_hanging_chad', 'j_rough_gem', 'j_bloodstone',
    'j_arrowhead', 'j_onyx_agate', 'j_glass', 'j_ring_master',
    'j_flower_pot', 'j_blueprint', 'j_wee', 'j_merry_andy',
    'j_oops', 'j_idol', 'j_seeing_double', 'j_matador', 'j_hit_the_road',
    'j_duo', 'j_trio', 'j_family', 'j_order', 'j_tribe', 'j_stuntman',
    'j_invisible', 'j_brainstorm', 'j_satellite', 'j_shoot_the_moon',
    'j_drivers_license', 'j_cartomancer', 'j_astronomer', 'j_burnt',
    'j_bootstraps', 'j_canio', 'j_triboulet', 'j_yorick', 'j_chicot', 'j_perkeo'
}

-- Mika's Mod Collection jokers (if enabled)
local mikas_jokers = {
    'j_mmc_prime_time', 'j_mmc_straight_nate', 'j_mmc_fisherman', 'j_mmc_impatient',
    'j_mmc_cultist', 'j_mmc_seal_collector', 'j_mmc_camper', 'j_mmc_scratch_card',
    'j_mmc_delayed', 'j_mmc_showoff', 'j_mmc_sniper', 'j_mmc_blackjack',
    'j_mmc_batman', 'j_mmc_bomb', 'j_mmc_eye_chart', 'j_mmc_grudgeful',
    'j_mmc_finishing_blow', 'j_mmc_aurora_borealis', 'j_mmc_historical', 'j_mmc_suit_alley',
    'j_mmc_printer', 'j_mmc_training_wheels', 'j_mmc_horseshoe', 'j_mmc_incomplete',
    'j_mmc_abbey_road', 'j_mmc_fishing_license', 'j_mmc_gold_bar', 'j_mmc_rigged',
    'j_mmc_commander', 'j_mmc_blue_moon', 'j_mmc_dagonet', 'j_mmc_glue',
    'j_mmc_harp_seal', 'j_mmc_football_card', 'j_mmc_special_edition', 'j_mmc_stockpiler',
    'j_mmc_student_loans', 'j_mmc_broke', 'j_mmc_go_for_broke', 'j_mmc_street_fighter',
    'j_mmc_checklist', 'j_mmc_one_of_us', 'j_mmc_investor', 'j_mmc_mountain_climber',
    'j_mmc_shackles', 'j_mmc_buy_one_get_one', 'j_mmc_pack_a_punch', 'j_mmc_seal_steal',
    'j_mmc_tax_collector', 'j_mmc_glass_cannon', 'j_mmc_scoring_test', 'j_mmc_cicero',
    'j_mmc_dawn', 'j_mmc_savings', 'j_mmc_monopolist', 'j_mmc_nebula',
    'j_mmc_cheapskate', 'j_mmc_psychic', 'j_mmc_cheat', 'j_mmc_plus_one'
}

-- Function to check if Mika's Mod Collection is enabled
local function is_mikas_mod_enabled()
    -- Check if any Mika's jokers exist in the game
    if SMODS and SMODS.Jokers then
        for _, joker_key in ipairs(mikas_jokers) do
            if SMODS.Jokers[joker_key] then
                return true
            end
        end
    end
    return false
end

-- Enhancement and seal options
local enhancement_options = {
    {key = 'base', name = 'Base'},
    {key = 'm_bonus', name = 'Bonus'},
    {key = 'm_mult', name = 'Mult'},
    {key = 'm_wild', name = 'Wild'},
    {key = 'm_glass', name = 'Glass'},
    {key = 'm_steel', name = 'Steel'},
    {key = 'm_stone', name = 'Stone'},
    {key = 'm_gold', name = 'Gold'},
    {key = 'm_lucky', name = 'Lucky'}
}

local seal_options = {
    {key = 'none', name = 'No Seal'},
    {key = 'Gold', name = 'Gold Seal'},
    {key = 'Red', name = 'Red Seal'},
    {key = 'Blue', name = 'Blue Seal'},
    {key = 'Purple', name = 'Purple Seal'}
}

-- Current enhancement/seal selection
mod.config.current_enhancement = mod.config.current_enhancement or 'base'
mod.config.current_seal = mod.config.current_seal or 'none'

-- Save config function
local function save_config()
    SMODS.save_mod_config(mod)
end

-- Simple overlay creation function
local function create_overlay(content)
    if G.OVERLAY_MENU then
        G.OVERLAY_MENU:remove()
        G.OVERLAY_MENU = nil
    end
    
    G.OVERLAY_MENU = UIBox{
        definition = content,
        config = {offset = {x=0,y=0}, align = 'cm', parent = G.OVERLAY}
    }
end

-- Convert legacy deck format to enhanced format
local function convert_legacy_deck()
    if #mod.config.custom_deck > 0 then
        local needs_conversion = false
        
        -- Check if any cards are still in old string format
        for _, card_data in ipairs(mod.config.custom_deck) do
            if type(card_data) == "string" then
                needs_conversion = true
                break
            end
        end
        
        if needs_conversion then
            local new_deck = {}
            for _, card_id in ipairs(mod.config.custom_deck) do
                if type(card_id) == "string" then
                    local rank = card_id:sub(1, 1)
                    local suit = card_id:sub(2, 2)
                    table.insert(new_deck, create_card_data(rank, suit))
                else
                    table.insert(new_deck, card_id)
                end
            end
            mod.config.custom_deck = new_deck
            save_config()
        end
    end
end

-- Initialize legacy conversion
convert_legacy_deck()

-- Main settings menu
local function create_settings_menu()
    local menu_nodes = {
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
         nodes = {{n = G.UIT.T, config = {text = "ZOKERS MOD MENU", scale = 0.8}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Money: $" .. tostring(mod.config.starting_money), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Hands: " .. tostring(mod.config.starting_hands), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Discards: " .. tostring(mod.config.starting_discards), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Hand Size: " .. tostring(mod.config.hand_size), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Free Rerolls: " .. (mod.config.free_rerolls and "Yes" or "No"), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Joker Slots: " .. tostring(mod.config.joker_slots), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Consumable Slots: " .. tostring(mod.config.consumable_slots), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Custom Deck: " .. tostring(#mod.config.custom_deck) .. " cards", scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Starting Jokers: " .. tostring(#mod.config.starting_jokers), scale = 0.5}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.2}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_open_money_menu", hover = true, minw = 2}, 
             nodes = {{n = G.UIT.T, config = {text = "Money & Stats", scale = 0.4}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_open_deck_builder", hover = true, minw = 2}, 
             nodes = {{n = G.UIT.T, config = {text = "Build Deck", scale = 0.4}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_open_joker_menu", hover = true, minw = 2}, 
             nodes = {{n = G.UIT.T, config = {text = "Select Jokers", scale = 0.4}}}}
        }}
    }

    -- Add Mika's Jokers button if mod is enabled
    if is_mikas_mod_enabled() then
        table.insert(menu_nodes, {n = G.UIT.R, config = {align = "cm", padding = 0.1}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_open_mikas_joker_menu", hover = true, minw = 3, colour = {0.98, 0.36, 0.66, 1}}, 
             nodes = {{n = G.UIT.T, config = {text = "Mika's Jokers", scale = 0.4, colour = G.C.WHITE}}}}
        }})
    end

    -- Add close button and console info
    table.insert(menu_nodes, {n = G.UIT.R, config = {align = "cm", padding = 0.2}, nodes = {
        {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_close_menu", hover = true, minw = 2}, 
         nodes = {{n = G.UIT.T, config = {text = "Close", scale = 0.4}}}}
    }})
    
    table.insert(menu_nodes, {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
     nodes = {{n = G.UIT.T, config = {text = "Console: cs_money(10), cs_hands(6), etc.", scale = 0.3}}}})

    return {
        n = G.UIT.ROOT,
        config = {align = "cm", minw = 8, minh = 10},
        nodes = menu_nodes
    }
end

-- Money and stats adjustment menu with FREE REROLLS moved to bottom
local function create_money_menu()
    return {
        n = G.UIT.ROOT,
        config = {align = "cm", minw = 8, minh = 10},
        nodes = {
            {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
             nodes = {{n = G.UIT.T, config = {text = "MONEY & STATS", scale = 0.7}}}},
            
            -- Money Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Money:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_money_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = "$" .. tostring(mod.config.starting_money), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_money_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Hands Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Hands:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_hands_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = tostring(mod.config.starting_hands), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_hands_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Discards Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Discards:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_discards_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = tostring(mod.config.starting_discards), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_discards_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Joker Slots Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Joker Slots:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_slots_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = tostring(mod.config.joker_slots), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_slots_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Consumable Slots Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Consumable Slots:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_consumables_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = tostring(mod.config.consumable_slots), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_consumables_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Hand Size Row
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Hand Size:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_hand_size_down", hover = true, minw = 0.8, minh = 0.6, colour = G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = "-", scale = 0.6, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.08, minw = 1.5, minh = 0.6, colour = G.C.BLACK, outline = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = tostring(mod.config.hand_size), scale = 0.5, colour = G.C.WHITE}}}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_hand_size_up", hover = true, minw = 0.8, minh = 0.6, colour = G.C.GREEN}, 
                 nodes = {{n = G.UIT.T, config = {text = "+", scale = 0.6, colour = G.C.WHITE}}}}
            }},
            
            -- Free Rerolls Row - MOVED TO BOTTOM
            {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
                {n = G.UIT.T, config = {text = "Free Rerolls:", scale = 0.5, colour = G.C.WHITE}},
                {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_toggle_free_rerolls", hover = true, minw = 1.5, minh = 0.6, colour = mod.config.free_rerolls and G.C.GREEN or G.C.RED}, 
                 nodes = {{n = G.UIT.T, config = {text = mod.config.free_rerolls and "YES" or "NO", scale = 0.5, colour = G.C.WHITE}}}}
            }},
            
            {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
             nodes = {{n = G.UIT.T, config = {text = "Use console commands for exact values", scale = 0.3}}}},
            
            {n = G.UIT.R, config = {align = "cm", padding = 0.2}, nodes = {
                {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_back_to_main", hover = true, minw = 2}, 
                 nodes = {{n = G.UIT.T, config = {text = "Back", scale = 0.4}}}}
            }}
        }
    }
end

-- IMPROVED deck builder with better UI and functional enhancements/seals
local function create_deck_builder()
    local suits = {'S', 'H', 'D', 'C'}
    local suit_names = {'Spades', 'Hearts', 'Diamonds', 'Clubs'}
    local ranks = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'}
    
    -- Get current enhancement/seal display names
    local current_enhancement_name = "Base"
    for _, enh in ipairs(enhancement_options) do
        if enh.key == mod.config.current_enhancement then
            current_enhancement_name = enh.name
            break
        end
    end
    
    local current_seal_name = "No Seal"
    for _, seal in ipairs(seal_options) do
        if seal.key == mod.config.current_seal then
            current_seal_name = seal.name
            break
        end
    end
    
    local deck_nodes = {
        -- Title
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
         nodes = {{n = G.UIT.T, config = {text = "DECK BUILDER", scale = 0.7}}}},
        
        -- Deck info
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
         nodes = {{n = G.UIT.T, config = {text = "Deck: " .. mod.config.current_deck_name, scale = 0.4}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Size: " .. tostring(#mod.config.custom_deck) .. "/104 cards", scale = 0.4}}}},
        
        -- Enhancement/Seal controls - IMPROVED UI with colored buttons
        {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_cycle_enhancement", hover = true, minw = 3, minh = 0.8, colour = G.C.BLUE}, 
             nodes = {{n = G.UIT.T, config = {text = "Enhancement: " .. current_enhancement_name, scale = 0.35, colour = G.C.WHITE}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_cycle_seal", hover = true, minw = 3, minh = 0.8, colour = G.C.PURPLE}, 
             nodes = {{n = G.UIT.T, config = {text = "Seal: " .. current_seal_name, scale = 0.35, colour = G.C.WHITE}}}}
        }},
        
        -- Instructions
        {n = G.UIT.R, config = {align = "cm", padding = 0.05}, 
         nodes = {{n = G.UIT.T, config = {text = "Click cards to add with current enhancement/seal", scale = 0.35}}}},
        
        -- Action buttons - IMPROVED UI with proper colors
        {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_clear_deck", hover = true, minw = 1.8, minh = 0.8, colour = G.C.RED}, 
             nodes = {{n = G.UIT.T, config = {text = "Clear All", scale = 0.4, colour = G.C.WHITE}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_standard_deck", hover = true, minw = 1.8, minh = 0.8, colour = G.C.GREEN}, 
             nodes = {{n = G.UIT.T, config = {text = "Standard 52", scale = 0.4, colour = G.C.WHITE}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_save_deck", hover = true, minw = 1.8, minh = 0.8, colour = G.C.GOLD}, 
             nodes = {{n = G.UIT.T, config = {text = "Save Deck", scale = 0.4, colour = G.C.BLACK}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.05, button = "cs_back_to_main", hover = true, minw = 1.8, minh = 0.8, colour = G.C.GREY}, 
             nodes = {{n = G.UIT.T, config = {text = "Back", scale = 0.4, colour = G.C.WHITE}}}}
        }}
    }
    
    -- Card grid - clean and organized with better display
    for i, suit in ipairs(suits) do
        local suit_row = {
            n = G.UIT.R,
            config = {align = "cm", padding = 0.03},
            nodes = {
                {n = G.UIT.C, config = {align = "cm", minw = 1.2}, 
                 nodes = {{n = G.UIT.T, config = {text = suit_names[i] .. ":", scale = 0.4, colour = G.C.WHITE}}}}
            }
        }
        
        for j, rank in ipairs(ranks) do
            local count = 0
            
            -- Count cards of this rank/suit
            for _, card_data in ipairs(mod.config.custom_deck) do
                if (type(card_data) == "table" and card_data.rank == rank and card_data.suit == suit) or
                   (type(card_data) == "string" and card_data == rank .. suit) then
                    count = count + 1
                end
            end
            
            local button_text = rank
            if count > 0 then
                button_text = rank .. "(" .. count .. ")"
            end
            
            -- Color code based on count
            local button_colour = G.C.WHITE
            if count > 0 then
                button_colour = G.C.GREEN
            end
            if count >= 4 then
                button_colour = G.C.GOLD
            end
            if count >= 6 then
                button_colour = G.C.RED
            end
            
            table.insert(suit_row.nodes, {
                n = G.UIT.C,
                config = {
                    align = "cm",
                    padding = 0.02,
                    button = "cs_add_card",
                    ref_table = {rank = rank, suit = suit},
                    hover = true,
                    minw = 0.7,
                    minh = 0.4,
                    colour = button_colour
                },
                nodes = {
                    {n = G.UIT.T, config = {text = button_text, scale = 0.3, colour = G.C.BLACK}}
                }
            })
        end
        
        table.insert(deck_nodes, suit_row)
    end
    
    return {
        n = G.UIT.ROOT,
        config = {align = "cm", minw = 12, minh = 12},
        nodes = deck_nodes
    }
end

-- Generic joker selection menu function
local function create_joker_selection_menu(joker_list, title, is_mikas)
    mod.config.joker_page = mod.config.joker_page or 1
    mod.config.mikas_joker_page = mod.config.mikas_joker_page or 1
    
    local current_page = is_mikas and (mod.config.mikas_joker_page or 1) or (mod.config.joker_page or 1)
    local jokers_per_page = 24
    local start_index = (current_page - 1) * jokers_per_page + 1
    local end_index = math.min(start_index + jokers_per_page - 1, #joker_list)
    local total_pages = math.ceil(#joker_list / jokers_per_page)
    
    local joker_nodes = {
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
         nodes = {{n = G.UIT.T, config = {text = title, scale = 0.7}}}},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, 
         nodes = {{n = G.UIT.T, config = {text = "Selected: " .. tostring(#mod.config.starting_jokers) .. " | Page: " .. current_page .. "/" .. total_pages, scale = 0.4}}}},
        
        -- Navigation Layout
        {n = G.UIT.R, config = {align = "cm", padding = 0.15}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = is_mikas and "cs_mikas_joker_prev_page" or "cs_joker_prev_page", hover = true, minw = 2, minh = 0.8, colour = G.C.BLUE}, 
             nodes = {{n = G.UIT.T, config = {text = "◀ Previous", scale = 0.4, colour = G.C.WHITE}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = is_mikas and "cs_mikas_joker_next_page" or "cs_joker_next_page", hover = true, minw = 2, minh = 0.8, colour = G.C.BLUE}, 
             nodes = {{n = G.UIT.T, config = {text = "Next ▶", scale = 0.4, colour = G.C.WHITE}}}}
        }},
        
        {n = G.UIT.R, config = {align = "cm", padding = 0.1}, nodes = {
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_clear_jokers", hover = true, minw = 2.5, minh = 0.8, colour = G.C.RED}, 
             nodes = {{n = G.UIT.T, config = {text = "Clear All", scale = 0.4, colour = G.C.WHITE}}}},
            {n = G.UIT.C, config = {align = "cm", padding = 0.1, button = "cs_back_to_main", hover = true, minw = 2, minh = 0.8, colour = G.C.GREY}, 
             nodes = {{n = G.UIT.T, config = {text = "Back", scale = 0.4, colour = G.C.WHITE}}}}
        }}
    }
    
    local joker_grid = {n = G.UIT.R, config = {align = "cm", padding = 0.05}, nodes = {}}
    
    for i = start_index, end_index do
        if (i - start_index) % 6 == 0 then
            table.insert(joker_grid.nodes, {n = G.UIT.R, config = {align = "cm", padding = 0.02}, nodes = {}})
        end
        
        local joker_key = joker_list[i]
        if joker_key then
            local count = 0
            
            -- Count how many of this joker we have
            for _, selected in ipairs(mod.config.starting_jokers) do
                if selected == joker_key then
                    count = count + 1
                end
            end
            
            local joker_name = joker_key:gsub("j_", ""):gsub("j_mmc_", ""):gsub("_", " ")
            local display_text = joker_name
            if count > 0 then
                display_text = joker_name .. " (" .. count .. ")"
            end
            
            -- UPDATED: New color coding for 20 limit
            local button_colour = G.C.WHITE
            if count > 0 and count <= 9 then
                button_colour = G.C.GREEN  -- 1-9: Green
            elseif count >= 10 and count <= 19 then
                button_colour = G.C.GOLD   -- 10-19: Gold
            elseif count >= 20 then
                button_colour = G.C.RED    -- 20+: Red
            end
            
            table.insert(joker_grid.nodes[#joker_grid.nodes].nodes, {
                n = G.UIT.C,
                config = {
                    align = "cm",
                    padding = 0.05,
                    button = "cs_toggle_joker",
                    ref_table = {joker_key = joker_key},
                    hover = true,
                    minw = 1.5,
                    minh = 0.6,
                    colour = button_colour
                },
                nodes = {
                    {n = G.UIT.T, config = {text = display_text, scale = 0.22, colour = G.C.BLACK}}
                }
            })
        end
    end
    
    table.insert(joker_nodes, joker_grid)
    
    return {
        n = G.UIT.ROOT,
        config = {align = "cm", minw = 12, minh = 10},
        nodes = joker_nodes
    }
end

-- Vanilla joker selection menu
local function create_joker_menu()
    return create_joker_selection_menu(available_jokers, "SELECT STARTING JOKERS", false)
end

-- Mika's joker selection menu
local function create_mikas_joker_menu()
    return create_joker_selection_menu(mikas_jokers, "SELECT MIKA'S JOKERS", true)
end

-- Button Functions
G.FUNCS.cs_open_main_menu = function(e)
    create_overlay(create_settings_menu())
end

G.FUNCS.cs_open_money_menu = function(e)
    create_overlay(create_money_menu())
end

G.FUNCS.cs_open_deck_builder = function(e)
    create_overlay(create_deck_builder())
end

G.FUNCS.cs_open_joker_menu = function(e)
    create_overlay(create_joker_menu())
end

G.FUNCS.cs_open_mikas_joker_menu = function(e)
    create_overlay(create_mikas_joker_menu())
end

G.FUNCS.cs_back_to_main = function(e)
    create_overlay(create_settings_menu())
end

G.FUNCS.cs_close_menu = function(e)
    if G.OVERLAY_MENU then
        G.OVERLAY_MENU:remove()
        G.OVERLAY_MENU = nil
    end
end

-- Enhancement and seal cycling with proper display names
G.FUNCS.cs_cycle_enhancement = function(e)
    local current_index = 1
    for i, enh in ipairs(enhancement_options) do
        if enh.key == mod.config.current_enhancement then
            current_index = i
            break
        end
    end
    
    current_index = current_index + 1
    if current_index > #enhancement_options then
        current_index = 1
    end
    
    mod.config.current_enhancement = enhancement_options[current_index].key
    save_config()
    create_overlay(create_deck_builder())
    print("Enhancement set to: " .. enhancement_options[current_index].name)
end

G.FUNCS.cs_cycle_seal = function(e)
    local current_index = 1
    for i, seal in ipairs(seal_options) do
        if seal.key == mod.config.current_seal then
            current_index = i
            break
        end
    end
    
    current_index = current_index + 1
    if current_index > #seal_options then
        current_index = 1
    end
    
    mod.config.current_seal = seal_options[current_index].key
    save_config()
    create_overlay(create_deck_builder())
    print("Seal set to: " .. seal_options[current_index].name)
end

-- Save deck function
G.FUNCS.cs_save_deck = function(e)
    print("Enter deck name: cs_name_deck('My Deck Name')")
    print("Then save with: cs_save_current_deck()")
end

-- Free rerolls toggle
G.FUNCS.cs_toggle_free_rerolls = function(e)
    mod.config.free_rerolls = not mod.config.free_rerolls
    save_config()
    create_overlay(create_money_menu())
    print("Free rerolls: " .. (mod.config.free_rerolls and "ON" or "OFF"))
end

-- Adjustment functions - INCREASED CAPS
G.FUNCS.cs_money_up = function(e)
    mod.config.starting_money = math.min(mod.config.starting_money + 1, 999)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_money_down = function(e)
    mod.config.starting_money = math.max(mod.config.starting_money - 1, 0)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_hands_up = function(e)
    mod.config.starting_hands = math.min(mod.config.starting_hands + 1, 20)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_hands_down = function(e)
    mod.config.starting_hands = math.max(mod.config.starting_hands - 1, 1)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_discards_up = function(e)
    mod.config.starting_discards = math.min(mod.config.starting_discards + 1, 20)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_discards_down = function(e)
    mod.config.starting_discards = math.max(mod.config.starting_discards - 1, 0)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_slots_up = function(e)
    mod.config.joker_slots = math.min(mod.config.joker_slots + 1, 100)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_slots_down = function(e)
    mod.config.joker_slots = math.max(mod.config.joker_slots - 1, 0)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_consumables_up = function(e)
    mod.config.consumable_slots = math.min(mod.config.consumable_slots + 1, 15)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_consumables_down = function(e)
    mod.config.consumable_slots = math.max(mod.config.consumable_slots - 1, 0)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_hand_size_up = function(e)
    mod.config.hand_size = math.min(mod.config.hand_size + 1, 30)
    save_config()
    create_overlay(create_money_menu())
end

G.FUNCS.cs_hand_size_down = function(e)
    mod.config.hand_size = math.max(mod.config.hand_size - 1, 1)
    save_config()
    create_overlay(create_money_menu())
end

-- IMPROVED Card button - adds cards with enhancements/seals
G.FUNCS.cs_add_card = function(e)
    local rank = e.config.ref_table.rank
    local suit = e.config.ref_table.suit
    local count = 0
    
    -- Count existing cards of this rank/suit
    for _, card_data in ipairs(mod.config.custom_deck) do
        if (type(card_data) == "table" and card_data.rank == rank and card_data.suit == suit) or
           (type(card_data) == "string" and card_data == rank .. suit) then
            count = count + 1
        end
    end
    
    if count < 6 and #mod.config.custom_deck < 104 then
        -- Add card with current enhancement and seal
        table.insert(mod.config.custom_deck, create_card_data(rank, suit, mod.config.current_enhancement, mod.config.current_seal))
        save_config()
        create_overlay(create_deck_builder())
        print("Added " .. rank .. suit .. " with " .. mod.config.current_enhancement .. " enhancement and " .. mod.config.current_seal .. " seal")
    else
        if count >= 6 then
            print("Max 6 copies of " .. rank .. suit)
        else
            print("Deck full (104 cards max)")
        end
    end
end

-- FIXED Deck functions with enhanced card support
G.FUNCS.cs_clear_deck = function(e)
    mod.config.custom_deck = {}
    save_config()
    create_overlay(create_deck_builder())
end

G.FUNCS.cs_standard_deck = function(e)
    mod.config.custom_deck = {}
    local suits = {'S', 'H', 'D', 'C'}
    local ranks = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'}
    
    for _, suit in ipairs(suits) do
        for _, rank in ipairs(ranks) do
            table.insert(mod.config.custom_deck, create_card_data(rank, suit))
        end
    end
    
    save_config()
    create_overlay(create_deck_builder())
    print("Created standard 52-card deck")
end

-- UPDATED: Joker functions - allow up to 20 same jokers (increased from 10)
G.FUNCS.cs_toggle_joker = function(e)
    local joker_key = e.config.ref_table.joker_key
    local count = 0
    
    -- Count how many of this joker we already have
    for _, selected in ipairs(mod.config.starting_jokers) do
        if selected == joker_key then
            count = count + 1
        end
    end
    
    if count > 0 and count < 20 then
        -- Add another copy (up to 20)
        table.insert(mod.config.starting_jokers, joker_key)
        print("Added " .. joker_key .. " (now have " .. (count + 1) .. ")")
    elseif count == 0 then
        -- Add first copy
        table.insert(mod.config.starting_jokers, joker_key)
        print("Added " .. joker_key .. " (1)")
    elseif count >= 20 then
        -- Remove all copies when at max
        for i = #mod.config.starting_jokers, 1, -1 do
            if mod.config.starting_jokers[i] == joker_key then
                table.remove(mod.config.starting_jokers, i)
            end
        end
        print("Removed all " .. joker_key)
    end
    
    save_config()
    -- Determine which menu to recreate based on joker type
    if string.find(joker_key, "mmc") then
        create_overlay(create_mikas_joker_menu())
    else
        create_overlay(create_joker_menu())
    end
end

G.FUNCS.cs_clear_jokers = function(e)
    mod.config.starting_jokers = {}
    save_config()
    create_overlay(create_joker_menu())
end

-- Vanilla joker pagination
G.FUNCS.cs_joker_next_page = function(e)
    local total_pages = math.ceil(#available_jokers / 24)
    mod.config.joker_page = (mod.config.joker_page or 1) + 1
    if mod.config.joker_page > total_pages then
        mod.config.joker_page = 1
    end
    save_config()
    create_overlay(create_joker_menu())
end

G.FUNCS.cs_joker_prev_page = function(e)
    local total_pages = math.ceil(#available_jokers / 24)
    mod.config.joker_page = (mod.config.joker_page or 1) - 1
    if mod.config.joker_page < 1 then
        mod.config.joker_page = total_pages
    end
    save_config()
    create_overlay(create_joker_menu())
end

-- Mika's joker pagination
G.FUNCS.cs_mikas_joker_next_page = function(e)
    local total_pages = math.ceil(#mikas_jokers / 24)
    mod.config.mikas_joker_page = (mod.config.mikas_joker_page or 1) + 1
    if mod.config.mikas_joker_page > total_pages then
        mod.config.mikas_joker_page = 1
    end
    save_config()
    create_overlay(create_mikas_joker_menu())
end

G.FUNCS.cs_mikas_joker_prev_page = function(e)
    local total_pages = math.ceil(#mikas_jokers / 24)
    mod.config.mikas_joker_page = (mod.config.mikas_joker_page or 1) - 1
    if mod.config.mikas_joker_page < 1 then
        mod.config.mikas_joker_page = total_pages
    end
    save_config()
    create_overlay(create_mikas_joker_menu())
end

-- Keybind setup
local function setup_keybind()

-- IMPROVED free rerolls system - hooks into shop reroll cost
local original_get_reroll_cost = get_reroll_cost or function() return 5 end

get_reroll_cost = function(...)
    if mod and mod.config and mod.config.free_rerolls then
        return 0
    else
        return original_get_reroll_cost(...)
    end
end

-- Also hook into shop updates to ensure rerolls stay free
local original_shop_update = nil
if G and G.FUNCS and G.FUNCS.reroll_shop then
    original_shop_update = G.FUNCS.reroll_shop
    G.FUNCS.reroll_shop = function(e)
        if mod and mod.config and mod.config.free_rerolls then
            -- Temporarily override reroll cost
            local original_cost = G.GAME.current_round and G.GAME.current_round.reroll_cost or 5
            if G.GAME.current_round then
                G.GAME.current_round.reroll_cost = 0
            end
            
            local result = original_shop_update(e)
            
            -- Keep it at 0 if free rerolls are enabled
            if G.GAME.current_round and mod.config.free_rerolls then
                G.GAME.current_round.reroll_cost = 0
            end
            
            return result
        else
            return original_shop_update(e)
        end
    end
end

-- Continuous update to ensure free rerolls stay active
local function update_free_rerolls()
    if mod and mod.config and mod.config.free_rerolls and G and G.GAME then
        if G.GAME.current_round then
            G.GAME.current_round.reroll_cost = 0
        end
        if G.STATE == G.STATES.SHOP then
            -- Force reroll cost to 0 in shop
            if G.GAME.current_round then
                G.GAME.current_round.reroll_cost = 0
            end
        end
    end
end

-- Hook into the game's update loop
local original_game_update = Game.update
Game.update = function(self, dt)
    local result = original_game_update(self, dt)
    update_free_rerolls()
    
    -- Ensure hand size is maintained
    if mod and mod.config and mod.config.hand_size and mod.config.hand_size ~= 8 then
        if G.hand and G.hand.config and G.hand.config.card_limit ~= mod.config.hand_size then
            G.hand.config.card_limit = mod.config.hand_size
        end
    end
    
    return result
end
    local original_keypressed = love.keypressed
    love.keypressed = function(key, scancode, isrepeat)
        if key == "c" or key == "C" then
            print("Opening ZokersModMenu...")
            G.FUNCS.cs_open_main_menu()
            return
        end
        
        if original_keypressed then
            original_keypressed(key, scancode, isrepeat)
        end
    end
    
    print("ZokersModMenu keybind installed: Press 'C' to open")
    print("Console Access: Press F7 key to open developer console")
end

setup_keybind()

-- FIXED Game application - custom deck as OPTIONAL overlay, not replacement
local original_start_run = Game.start_run
function Game:start_run(args)
    args = args or {}
    
    local result = original_start_run(self, args)
    
    if G.GAME then
        -- Apply custom money - FIXED timing
        if mod.config.starting_money and mod.config.starting_money ~= 4 then
            G.GAME.dollars = mod.config.starting_money
            print("Applied custom starting money: $" .. mod.config.starting_money)
        end
        
        if mod.config.starting_hands and mod.config.starting_hands ~= 4 then
            G.GAME.round_resets.hands = mod.config.starting_hands
            if G.GAME.current_round then
                G.GAME.current_round.hands_left = mod.config.starting_hands
            end
            print("Applied custom starting hands: " .. mod.config.starting_hands)
        end
        
        if mod.config.starting_discards and mod.config.starting_discards ~= 3 then
            G.GAME.round_resets.discards = mod.config.starting_discards
            if G.GAME.current_round then
                G.GAME.current_round.discards_left = mod.config.starting_discards
            end
            print("Applied custom starting discards: " .. mod.config.starting_discards)
        end
        
        -- Apply free rerolls - FIXED to work properly
        if mod.config.free_rerolls then
            -- Apply immediately and on every round
            if G.GAME.current_round then
                G.GAME.current_round.reroll_cost = 0
            end
            
            -- Also set the default reroll cost to 0
            if G.GAME then
                G.GAME.base_reroll_cost = 0
            end
            
            print("Applied free rerolls")
        end
        
        if mod.config.joker_slots and mod.config.joker_slots ~= 5 then
            if G.jokers and G.jokers.config then
                G.jokers.config.card_limit = mod.config.joker_slots
                print("Applied custom joker slots: " .. mod.config.joker_slots)
            end
        end
        
        if mod.config.consumable_slots and mod.config.consumable_slots ~= 2 then
            if G.consumeables and G.consumeables.config then
                G.consumeables.config.card_limit = mod.config.consumable_slots
                print("Applied custom consumable slots: " .. mod.config.consumable_slots)
            end
        end
        
        if mod.config.hand_size and mod.config.hand_size ~= 8 then
            -- Set hand size during game initialization
            if G.hand and G.hand.config then
                G.hand.config.card_limit = mod.config.hand_size
                print("Applied custom hand size: " .. mod.config.hand_size)
            end
            -- Also set it in the game state for consistency
            if G.GAME then
                G.GAME.starting_params = G.GAME.starting_params or {}
                G.GAME.starting_params.hand_size = mod.config.hand_size
            end
            -- Add delayed event to ensure it sticks
            G.E_MANAGER:add_event(Event({
                delay = 0.5,
                func = function()
                    if G.hand and G.hand.config then
                        G.hand.config.card_limit = mod.config.hand_size
                        print("Confirmed hand size set to: " .. mod.config.hand_size)
                    end
                    return true
                end
            }))
        end
        
        -- ONLY apply custom deck if explicitly enabled via console command
        if mod.config.use_custom_deck and mod.config.custom_deck and #mod.config.custom_deck > 0 then
            print("Applying custom deck with " .. #mod.config.custom_deck .. " cards...")
            
            -- Wait for full game initialization
            G.E_MANAGER:add_event(Event({
                delay = 0.5,
                func = function()
                    if G.deck and G.deck.cards then
                        -- Backup original cards before clearing
                        local original_cards = {}
                        for _, card in ipairs(G.deck.cards) do
                            table.insert(original_cards, card)
                        end
                        
                        -- Safely remove original cards
                        for _, card in ipairs(original_cards) do
                            if card and card.remove then
                                card:remove()
                            end
                        end
                        
                        -- Clear deck
                        G.deck.cards = {}
                        
                        -- Create new cards with enhancements/seals
                        for _, card_data in ipairs(mod.config.custom_deck) do
                            local rank, suit, enhancement, seal
                            
                            if type(card_data) == "table" then
                                rank = card_data.rank
                                suit = card_data.suit  
                                enhancement = card_data.enhancement or 'base'
                                seal = card_data.seal or 'none'
                            else
                                -- Legacy string format
                                rank = card_data:sub(1, 1)
                                suit = card_data:sub(2, 2)
                                enhancement = 'base'
                                seal = 'none'
                            end
                            
                            local suit_map = {S = 'Spades', H = 'Hearts', D = 'Diamonds', C = 'Clubs'}
                            local suit_name = suit_map[suit]
                            
                            if suit_name and rank and G.P_CARDS[suit_name .. '_' .. rank] then
                                -- Get enhancement center
                                local enhancement_center = G.P_CENTERS.c_base
                                if enhancement and enhancement ~= 'base' and G.P_CENTERS[enhancement] then
                                    enhancement_center = G.P_CENTERS[enhancement]
                                end
                                
                                -- Create card with proper enhancement
                                local card = Card(
                                    G.deck.T.x, G.deck.T.y,
                                    G.CARD_W, G.CARD_H,
                                    G.P_CARDS[suit_name .. '_' .. rank],
                                    enhancement_center,
                                    {playing_card = suit_name .. '_' .. rank}
                                )
                                
                                if card then
                                    -- Apply seal if not none
                                    if seal and seal ~= 'none' then
                                        card.seal = seal
                                    end
                                    
                                    -- Ensure FULL initialization
                                    card:set_base()
                                    card:add_to_deck()
                                    G.deck:emplace(card)
                                end
                            end
                        end
                        
                        print("Custom deck applied successfully: " .. #G.deck.cards .. " cards")
                        return true
                    end
                end
            }))
        elseif mod.config.custom_deck and #mod.config.custom_deck > 0 then
            print("Custom deck available (" .. #mod.config.custom_deck .. " cards) - use cs_enable_custom_deck() to activate")
        end
        
        -- FIXED joker creation
        if mod.config.starting_jokers and #mod.config.starting_jokers > 0 then
            G.E_MANAGER:add_event(Event({
                delay = 0.3,
                func = function()
                    for _, joker_key in ipairs(mod.config.starting_jokers) do
                        if G.jokers and G.P_CENTERS[joker_key] then
                            local joker = Card(
                                G.jokers.T.x, G.jokers.T.y,
                                G.CARD_W, G.CARD_H,
                                nil,
                                G.P_CENTERS[joker_key]
                            )
                            
                            if joker then
                                joker:add_to_deck()
                                G.jokers:emplace(joker)
                                print("Added starting joker: " .. joker_key)
                            end
                        end
                    end
                    return true
                end
            }))
        end
    end
    
    return result
end

-- Console commands - ALL RENAMED TO ZOKERSMODMENU
function cs_money(amount)
    if amount and type(amount) == "number" and amount >= 0 and amount <= 999 then
        mod.config.starting_money = amount
        save_config()
        print("ZokersModMenu: Starting money set to $" .. amount)
    else
        print("ZokersModMenu Usage: cs_money(amount) - amount must be 0-999")
        print("Current: $" .. (mod.config.starting_money or 4))
    end
end

function cs_hands(amount)
    if amount and type(amount) == "number" and amount >= 1 and amount <= 20 then
        mod.config.starting_hands = amount
        save_config()
        print("ZokersModMenu: Starting hands set to " .. amount)
    else
        print("ZokersModMenu Usage: cs_hands(amount) - amount must be 1-20")
        print("Current: " .. (mod.config.starting_hands or 4))
    end
end

function cs_discards(amount)
    if amount and type(amount) == "number" and amount >= 0 and amount <= 20 then
        mod.config.starting_discards = amount
        save_config()
        print("ZokersModMenu: Starting discards set to " .. amount)
    else
        print("ZokersModMenu Usage: cs_discards(amount) - amount must be 0-20")
        print("Current: " .. (mod.config.starting_discards or 3))
    end
end

function cs_free_rerolls(enabled)
    if enabled ~= nil then
        mod.config.free_rerolls = enabled
        save_config()
        print("ZokersModMenu: Free rerolls " .. (mod.config.free_rerolls and "ENABLED" or "DISABLED"))
    else
        print("ZokersModMenu Usage: cs_free_rerolls(true/false)")
        print("Current: " .. (mod.config.free_rerolls and "ON" or "OFF"))
    end
end

function cs_slots(amount)
    if amount and type(amount) == "number" and amount >= 0 and amount <= 100 then
        mod.config.joker_slots = amount
        save_config()
        print("ZokersModMenu: Joker slots set to " .. amount)
    else
        print("ZokersModMenu Usage: cs_slots(amount) - amount must be 0-100")
        print("Current: " .. (mod.config.joker_slots or 5))
    end
end

function cs_consumables(amount)
    if amount and type(amount) == "number" and amount >= 0 and amount <= 15 then
        mod.config.consumable_slots = amount
        save_config()
        print("ZokersModMenu: Consumable slots set to " .. amount)
    else
        print("ZokersModMenu Usage: cs_consumables(amount) - amount must be 0-15")
        print("Current: " .. (mod.config.consumable_slots or 2))
    end
end

function cs_hand_size(amount)
    if amount and type(amount) == "number" and amount >= 1 and amount <= 30 then
        mod.config.hand_size = amount
        save_config()
        print("ZokersModMenu: Hand size set to " .. amount)
    else
        print("ZokersModMenu Usage: cs_hand_size(amount) - amount must be 1-30")
        print("Current: " .. (mod.config.hand_size or 8))
    end
end

function cs_add_joker(joker_name)
    if joker_name and type(joker_name) == "string" then
        local joker_key = "j_" .. joker_name:lower():gsub(" ", "_")
        local found = false
        
        -- Check both vanilla and Mika's jokers
        for _, available in ipairs(available_jokers) do
            if available == joker_key then
                found = true
                break
            end
        end
        
        if not found then
            -- Check Mika's jokers
            for _, available in ipairs(mikas_jokers) do
                if available == joker_key then
                    found = true
                    break
                end
            end
        end
        
        if found then
            table.insert(mod.config.starting_jokers, joker_key)
            save_config()
            print("ZokersModMenu: Added starting joker: " .. joker_key)
        else
            print("ZokersModMenu: Joker not found: " .. joker_key)
            print("Try: cs_list_jokers() to see available jokers")
        end
    else
        print("ZokersModMenu Usage: cs_add_joker('joker_name')")
        print("Example: cs_add_joker('credit_card')")
    end
end

-- Enhanced deck save system with persistent storage - ZOKERSMODMENU BRANDING
function cs_name_deck(name)
    if name and type(name) == "string" and name ~= "" then
        mod.config.current_deck_name = name
        save_config()
        print("ZokersModMenu: Deck name set to: " .. name)
    else
        print("ZokersModMenu Usage: cs_name_deck('My Deck Name')")
        print("Current: " .. (mod.config.current_deck_name or "Custom Deck"))
    end
end

function cs_save_current_deck()
    if #mod.config.custom_deck == 0 then
        print("ZokersModMenu: No deck to save! Build a deck first.")
        return
    end
    
    -- Initialize saved_decks if it doesn't exist
    mod.config.saved_decks = mod.config.saved_decks or {}
    
    -- Save the current deck
    mod.config.saved_decks[mod.config.current_deck_name] = {}
    for _, card_data in ipairs(mod.config.custom_deck) do
        table.insert(mod.config.saved_decks[mod.config.current_deck_name], {
            rank = card_data.rank,
            suit = card_data.suit,
            enhancement = card_data.enhancement or 'base',
            seal = card_data.seal or 'none'
        })
    end
    
    save_config()
    print("ZokersModMenu: Saved deck: " .. mod.config.current_deck_name .. " (" .. #mod.config.custom_deck .. " cards)")
    print("Use cs_load_deck('" .. mod.config.current_deck_name .. "') to load it later")
end

function cs_load_deck(name)
    if not name or type(name) ~= "string" then
        print("ZokersModMenu: Available saved decks:")
        if mod.config.saved_decks then
            for deck_name, deck_data in pairs(mod.config.saved_decks) do
                print("- " .. deck_name .. " (" .. #deck_data .. " cards)")
            end
        else
            print("No saved decks found")
        end
        print("ZokersModMenu Usage: cs_load_deck('Deck Name')")
        return
    end
    
    if mod.config.saved_decks and mod.config.saved_decks[name] then
        mod.config.custom_deck = {}
        for _, card_data in ipairs(mod.config.saved_decks[name]) do
            table.insert(mod.config.custom_deck, {
                rank = card_data.rank,
                suit = card_data.suit,
                enhancement = card_data.enhancement or 'base',
                seal = card_data.seal or 'none'
            })
        end
        mod.config.current_deck_name = name
        save_config()
        print("ZokersModMenu: Loaded deck: " .. name .. " (" .. #mod.config.custom_deck .. " cards)")
    else
        print("ZokersModMenu: Deck not found: " .. name)
        cs_load_deck() -- Show available decks
    end
end

function cs_enable_custom_deck()
    if #mod.config.custom_deck == 0 then
        print("ZokersModMenu: No custom deck built! Use the deck builder first.")
        return
    end
    
    mod.config.use_custom_deck = true
    save_config()
    print("ZokersModMenu: Custom deck ENABLED - will be used in next game")
    print("Deck: " .. mod.config.current_deck_name .. " (" .. #mod.config.custom_deck .. " cards)")
    print("Use cs_disable_custom_deck() to use default deck again")
end

function cs_disable_custom_deck()
    mod.config.use_custom_deck = false
    save_config()
    print("ZokersModMenu: Custom deck DISABLED - will use default deck")
end

function cs_remove_card(card_id)
    if card_id and type(card_id) == "string" then
        card_id = card_id:upper()
        local rank = card_id:sub(1, 1)
        local suit = card_id:sub(2, 2)
        
        for i = #mod.config.custom_deck, 1, -1 do
            local card_data = mod.config.custom_deck[i]
            if (type(card_data) == "table" and card_data.rank == rank and card_data.suit == suit) or
               (type(card_data) == "string" and card_data == card_id) then
                table.remove(mod.config.custom_deck, i)
                save_config()
                print("ZokersModMenu: Removed " .. card_id)
                return
            end
        end
        print("ZokersModMenu: No " .. card_id .. " to remove")
    else
        print("ZokersModMenu Usage: cs_remove_card('AS') - removes one Ace of Spades")
        print("Card format: rank + suit (AS, 2H, TC, etc.)")
    end
end

function cs_list_jokers()
    print("=== AVAILABLE VANILLA JOKERS ===")
    for i, joker in ipairs(available_jokers) do
        local name = joker:gsub("j_", ""):gsub("_", " ")
        print(i .. ": " .. name .. " (" .. joker .. ")")
        if i % 10 == 0 then
            print("--- (Press any key to continue) ---")
        end
    end
    
    if is_mikas_mod_enabled() then
        print("\n=== AVAILABLE MIKA'S JOKERS ===")
        for i, joker in ipairs(mikas_jokers) do
            local name = joker:gsub("j_mmc_", ""):gsub("_", " ")
            print(i .. ": " .. name .. " (" .. joker .. ")")
            if i % 10 == 0 then
                print("--- (Press any key to continue) ---")
            end
        end
    end
    print("========================")
end

function cs_show()
    print("=== ZOKERS MOD MENU SETTINGS ===")
    print("Money: $" .. tostring(mod.config.starting_money or 4))
    print("Hands: " .. tostring(mod.config.starting_hands or 4))
    print("Discards: " .. tostring(mod.config.starting_discards or 3))
    print("Hand Size: " .. tostring(mod.config.hand_size or 8))
    print("Free Rerolls: " .. (mod.config.free_rerolls and "ON" or "OFF"))
    print("Joker Slots: " .. tostring(mod.config.joker_slots or 5))
    print("Consumable Slots: " .. tostring(mod.config.consumable_slots or 2))
    print("Custom Deck: " .. tostring(#(mod.config.custom_deck or {})) .. " cards")
    print("Custom Deck Enabled: " .. (mod.config.use_custom_deck and "YES" or "NO"))
    print("Starting Jokers: " .. tostring(#(mod.config.starting_jokers or {})))
    print("Mika's Mod Enabled: " .. (is_mikas_mod_enabled() and "YES" or "NO"))
    if mod.config.starting_jokers and #mod.config.starting_jokers > 0 then
        for i, joker in ipairs(mod.config.starting_jokers) do
            print("  " .. i .. ": " .. joker)
        end
    end
    print("Current Deck Name: " .. (mod.config.current_deck_name or "Custom Deck"))
    if mod.config.saved_decks then
        print("Saved Decks: " .. tostring(table.getn and table.getn(mod.config.saved_decks) or 0))
    else
        print("Saved Decks: 0")
    end
    print("=============================")
end

function cs_open()
    print("Opening ZokersModMenu...")
    G.FUNCS.cs_open_main_menu()
end

-- Startup message
print("=== ZOKERS MOD MENU LOADED v1.1.0 ===")
print("KEYBIND: Press 'C' anywhere to open ZokersModMenu")
print("CONSOLE: Press F7 to open console, then type commands")
print("NEW: Up to 20 copies of same joker supported!")
if is_mikas_mod_enabled() then
    print("NEW: Mika's Mod Collection detected - Mika's Jokers tab available!")
end
print("Console Commands Available:")
print("cs_open() - Open the ZokersModMenu")
print("cs_show() - Show current settings")
print("cs_money(10) - Set starting money")
print("cs_hands(6) - Set starting hands")
print("cs_discards(5) - Set starting discards")
print("cs_hand_size(10) - Set hand size")
print("cs_free_rerolls(true/false) - Toggle free rerolls")
print("cs_slots(10) - Set joker slots")
print("cs_consumables(5) - Set consumable slots")
print("cs_add_joker('joker_name') - Add starting joker")
print("cs_remove_card('AS') - Remove card from deck")
print("cs_list_jokers() - List all available jokers")
print("DECK SYSTEM:")
print("cs_name_deck('My Deck') - Name current deck")
print("cs_save_current_deck() - Save current deck")
print("cs_load_deck('Deck Name') - Load saved deck")
print("cs_enable_custom_deck() - Enable custom deck for games")
print("cs_disable_custom_deck() - Use default deck")
print("===============================")
print("CONSOLE: Press F7 key to open developer console")
print("IMPORTANT: Custom deck is OPTIONAL and disabled by default")
print("Build a deck, then use cs_enable_custom_deck() to activate it")
print("===============================")

----------------------------------------------
------------MOD CODE END----------------------